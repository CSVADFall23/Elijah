package ImageGlitch;

public enum Operation {ADD, MULT}
