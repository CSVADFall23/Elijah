package ImageGlitch;

public enum Direction {UP, DOWN, LEFT, RIGHT, RANDOM}

