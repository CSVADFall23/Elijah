package ImageGlitch;

public enum Value {RED, GREEN, BLUE, HUE, SAT, BRI, RANDOM}
